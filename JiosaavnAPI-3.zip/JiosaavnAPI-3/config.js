module.exports = {
  APP_URL: process.env.APP_URL || "https://jiosaavn-api.vercel.app", // don't give last slash
};
